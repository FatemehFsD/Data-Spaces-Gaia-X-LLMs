package eu.gaiax.federatedcatalogue.utils.exceptionhandler;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@RequiredArgsConstructor
@Slf4j
public class GaiaXExceptionHandler {
    //InvalidDidMethodException
    // WebDidException
    //InvalidServiceOfferingException
}
