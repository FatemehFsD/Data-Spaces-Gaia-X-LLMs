/*
 * Copyright (c) 2018, KEVA Health LLC and/or its affiliates. All rights reserved.
 */

package eu.gaiax.federatedcatalogue.neo4j;
public interface GaiaxEntity  {
}
