package eu.gaiax.federatedcatalogue.service;

public interface AbstractTypedIngestionService extends AbstractIngestionService {

    String getAcceptedType();

}
