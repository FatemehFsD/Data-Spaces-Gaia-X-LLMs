package eu.gaiax.federatedcatalogue.service.neo4j.model.resource;

public record LocationDTO(String countrySubdivisionCode) {
}
