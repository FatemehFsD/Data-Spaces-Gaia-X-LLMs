package eu.gaiax.federatedcatalogue.model.request;

public record PolicyValidatorRequest(String catalogueUrl,
                                     String serviceOfferId) {
}
