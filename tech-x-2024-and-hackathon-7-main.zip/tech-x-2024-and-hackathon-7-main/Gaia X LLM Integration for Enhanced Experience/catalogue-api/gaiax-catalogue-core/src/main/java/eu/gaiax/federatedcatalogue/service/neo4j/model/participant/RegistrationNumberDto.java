package eu.gaiax.federatedcatalogue.service.neo4j.model.participant;

public record RegistrationNumberDto(String type, String number) {
}
