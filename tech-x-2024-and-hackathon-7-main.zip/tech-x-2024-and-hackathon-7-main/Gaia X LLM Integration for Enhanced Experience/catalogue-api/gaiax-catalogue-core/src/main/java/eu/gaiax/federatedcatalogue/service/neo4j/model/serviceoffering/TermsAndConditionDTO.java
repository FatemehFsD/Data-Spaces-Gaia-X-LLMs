package eu.gaiax.federatedcatalogue.service.neo4j.model.serviceoffering;

public record TermsAndConditionDTO(String url, String hash) {
}
