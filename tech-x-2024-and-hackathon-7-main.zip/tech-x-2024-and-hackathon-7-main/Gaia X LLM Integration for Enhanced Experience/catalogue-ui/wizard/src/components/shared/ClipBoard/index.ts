export { ClipBoard } from './ClipBoard.component'
