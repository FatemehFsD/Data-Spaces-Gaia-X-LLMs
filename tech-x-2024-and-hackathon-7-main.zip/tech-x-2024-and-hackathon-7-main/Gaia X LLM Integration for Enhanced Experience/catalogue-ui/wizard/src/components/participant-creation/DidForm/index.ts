export { DidForm } from './DidForm.component'
