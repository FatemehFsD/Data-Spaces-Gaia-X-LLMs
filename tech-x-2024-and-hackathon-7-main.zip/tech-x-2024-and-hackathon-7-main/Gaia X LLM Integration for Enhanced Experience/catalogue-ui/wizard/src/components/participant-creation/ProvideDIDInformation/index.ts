export { ProvideDIDInformation } from './ProvideDIDInformation.component'
