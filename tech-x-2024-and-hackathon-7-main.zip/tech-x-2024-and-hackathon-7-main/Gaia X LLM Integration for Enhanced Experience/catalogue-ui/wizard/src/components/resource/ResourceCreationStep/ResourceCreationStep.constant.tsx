export const LegalBasisList = [
  { label: 'GDPR2018 Article 6.1.[a-f]', value: '6.1.[a-f]' },
  { label: 'GDPR2018 Article 6.1.4', value: '6.1.4' },
  { label: 'GDPR2018 Article 7', value: '7' },
  { label: 'GDPR2018 Article 9.2.[a-j]', value: '9.2.[a-j]' },
]
