export { DataGrid, type MRT_ColumnDef } from './DataGrid.component'
