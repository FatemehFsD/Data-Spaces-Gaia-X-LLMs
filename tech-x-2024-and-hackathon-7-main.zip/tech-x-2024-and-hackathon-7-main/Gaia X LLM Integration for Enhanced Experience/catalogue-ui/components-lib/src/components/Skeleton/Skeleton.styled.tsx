import { styled } from '@mui/material/styles'
import { Skeleton } from '@mui/material'

const StyledSkeleton = styled(Skeleton)``

export { StyledSkeleton }
