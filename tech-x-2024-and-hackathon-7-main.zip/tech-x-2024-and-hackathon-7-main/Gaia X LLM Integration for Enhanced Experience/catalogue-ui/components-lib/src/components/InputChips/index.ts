export { InputChips } from './InputChips.component'
