export { ProfileImage, type ProfileImagePros } from './ProfileImage.component'
