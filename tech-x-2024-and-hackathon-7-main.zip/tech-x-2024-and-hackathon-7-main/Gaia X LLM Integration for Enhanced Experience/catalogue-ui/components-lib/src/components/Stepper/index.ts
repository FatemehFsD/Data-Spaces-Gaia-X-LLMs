export { Stepper, type StepperProps } from './Stepper.component'
