export {
  FormStepper,
  type StepperProps as FormStepperProps,
} from './FormStepper.component'
