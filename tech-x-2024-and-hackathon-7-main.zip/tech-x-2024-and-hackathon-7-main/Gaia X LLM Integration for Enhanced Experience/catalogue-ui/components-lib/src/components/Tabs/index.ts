export { CustomTabs } from './Tabs.component'
