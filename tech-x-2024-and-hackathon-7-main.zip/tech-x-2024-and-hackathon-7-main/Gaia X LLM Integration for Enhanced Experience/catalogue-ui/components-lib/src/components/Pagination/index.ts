export { Pagination } from './Pagination.component'
