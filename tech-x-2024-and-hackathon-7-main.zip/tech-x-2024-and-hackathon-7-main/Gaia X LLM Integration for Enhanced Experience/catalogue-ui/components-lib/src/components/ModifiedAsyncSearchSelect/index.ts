export {
  AsyncSearchSelect as ModifiedAsyncSearchSelect,
  type AsyncSearchSelectCompProps as ModifiedAsyncSearchSelectCompProps,
} from './AsyncSearchSelect.component'
