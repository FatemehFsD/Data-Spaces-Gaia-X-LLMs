export { ProgressBar, type ProgressPros } from './ProgressBar.component'
