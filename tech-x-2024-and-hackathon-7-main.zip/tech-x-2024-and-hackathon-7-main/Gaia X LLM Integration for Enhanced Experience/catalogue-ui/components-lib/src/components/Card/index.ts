export { Card, type CardPros } from './Card.component'
