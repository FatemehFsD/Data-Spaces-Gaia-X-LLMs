import Divider from '@mui/material/Divider'
import { styled } from '@mui/material/styles'
export const StyledDivider = styled(Divider)``
