export { Divider, type DividerProps } from './Divider.component'
