export { CatalogueCard } from './CatalogueCard.component'
