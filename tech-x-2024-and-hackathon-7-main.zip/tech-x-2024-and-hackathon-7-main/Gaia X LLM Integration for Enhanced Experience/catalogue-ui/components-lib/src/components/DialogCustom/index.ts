export {
  DialogComp as DialogCustom,
  type DialogTitleProps as CustomDialogTitleProps,
} from './DialogCustom.component'
