export { Badge } from './Badge.component'
