export { WalletCard, type WalletCardPros } from './WalletCard.component'
