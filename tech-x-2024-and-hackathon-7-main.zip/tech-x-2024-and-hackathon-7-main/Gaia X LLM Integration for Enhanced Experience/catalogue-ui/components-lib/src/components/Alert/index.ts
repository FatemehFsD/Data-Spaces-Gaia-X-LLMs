export {
  Alert,
  toast,
  ToastBody,
  Slide,
  ToastCloseIcon,
  StyledToastContainer,
} from './Alert.component'
import { ToastPosition } from './Alert.component'
export type { ToastPosition }
