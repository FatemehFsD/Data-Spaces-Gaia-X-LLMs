export { DialogComp as Dialog, type DialogTitleProps } from './Dialog.component'
