export interface IconType {
  width?: number
  height?: number
  fill?: string
  fill1?: string
}
