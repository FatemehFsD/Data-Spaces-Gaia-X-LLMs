// import SearchServices from './SearchServices.page'
// import { render, screen } from '@testing-library/react'

describe('Describe', () => {
  it('render correctly search services component', () => {
    // render(<SearchServices />)
    // expect(screen.getByText(/Search Services/i))
  })
})
