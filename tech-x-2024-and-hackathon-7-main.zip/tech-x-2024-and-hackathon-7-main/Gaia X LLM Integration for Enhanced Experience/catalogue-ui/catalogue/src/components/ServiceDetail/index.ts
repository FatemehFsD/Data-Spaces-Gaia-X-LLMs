export { ServiceDetail } from './ServiceDetail.component'
