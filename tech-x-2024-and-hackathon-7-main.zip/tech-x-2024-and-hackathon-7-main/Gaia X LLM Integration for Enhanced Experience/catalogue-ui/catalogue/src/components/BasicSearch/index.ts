export { BasicSearch } from './BasicSearch.component'
