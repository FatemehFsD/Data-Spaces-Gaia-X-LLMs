export { ErrorPage } from './ErrorPage.component'
