export { AppLoader } from './AppLoader.component'
