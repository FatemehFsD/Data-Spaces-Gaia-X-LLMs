export interface Selector {
  property: string
  edge: string
  field: string
  options: string[]
}
