import { PageNotFound } from '@catalogue/components'

const PageNotFoundPage = () => {
  return <PageNotFound />
}

export default PageNotFoundPage
