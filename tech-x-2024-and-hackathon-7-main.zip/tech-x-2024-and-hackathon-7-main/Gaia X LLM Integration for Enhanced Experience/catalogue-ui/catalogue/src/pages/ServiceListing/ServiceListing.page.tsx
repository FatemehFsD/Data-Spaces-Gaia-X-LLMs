import { ServiceListing as ServiceListingComp } from '@catalogue/components'

const ServiceListingPage = () => {
  return <ServiceListingComp />
}
export default ServiceListingPage
